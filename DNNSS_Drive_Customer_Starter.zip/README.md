# DNNSS Drive Customer APK starter

This is a **demo starter**, not a live ride-hailing service. It provides a Bike/Auto/Car selector, pickup/drop text fields, and demo fare/booking confirmation. It does not contact drivers or use live GPS, OTP, payments, or a production backend.

## Build APK using only an Android phone

1. Download and extract this ZIP on your phone if your file manager supports it.
2. Open https://github.com/ and sign in or create an account.
3. Create a new repository named `dnnss-drive-customer`. Keep it private if you prefer.
4. On the repository page, choose **Add file → Upload files**. Upload the contents of this project (including `lib/main.dart`, `pubspec.yaml`, and `.github/workflows/build-apk.yml`) so these files appear at the repository root. Do not upload the ZIP as a single file.
5. Commit the uploaded files to the `main` branch.
6. Open the repository's **Actions** tab. If prompted, enable GitHub Actions.
7. Select **Build DNNSS Drive Customer APK**, press **Run workflow**, and confirm.
8. Wait until the workflow run finishes with a green check. Open that run, scroll to **Artifacts**, and download `DNNSS-Drive-Customer-APK`.
9. Extract the downloaded artifact ZIP. Inside it should be `app-release.apk`.
10. Tap the APK on your phone to install. If Android asks, allow installation from that browser/file manager for this install, then open DNNSS Drive.

## Notes
- GitHub's mobile website controls may be easier in Chrome's **Desktop site** mode.
- The first APK is unsigned for Play Store publishing; GitHub's Flutter build creates a release APK suitable for local testing, but Play Store release requires a properly signed app and other policy/compliance steps.
- The displayed fares are placeholders. Set real fares only after deciding a pricing policy and connecting a secure backend.
- Never place passwords, API secret keys, payment secrets, or Supabase service-role keys in the app source.
