import 'package:flutter/material.dart';

void main() => runApp(const DnnssDriveApp());

const brandYellow = Color(0xFFFFC928);
const brandBlack = Color(0xFF151515);

class DnnssDriveApp extends StatelessWidget {
  const DnnssDriveApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'DNNSS Drive',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: brandYellow),
        scaffoldBackgroundColor: const Color(0xFFF7F7F7),
        appBarTheme: const AppBarTheme(
          backgroundColor: brandBlack,
          foregroundColor: Colors.white,
          centerTitle: false,
        ),
      ),
      home: const BookingHomePage(),
    );
  }
}

class BookingHomePage extends StatefulWidget {
  const BookingHomePage({super.key});

  @override
  State<BookingHomePage> createState() => _BookingHomePageState();
}

class _BookingHomePageState extends State<BookingHomePage> {
  String vehicle = 'Bike';
  final pickupController = TextEditingController();
  final dropController = TextEditingController();
  String? bookingMessage;

  int get fare {
    switch (vehicle) {
      case 'Auto':
        return 80;
      case 'Car':
        return 150;
      default:
        return 40;
    }
  }

  @override
  void dispose() {
    pickupController.dispose();
    dropController.dispose();
    super.dispose();
  }

  void bookRide() {
    if (pickupController.text.trim().isEmpty ||
        dropController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Pickup aur drop location bharein.')),
      );
      return;
    }
    setState(() {
      bookingMessage =
          'Demo booking taiyar hai!\\n${vehicle} • ₹$fare se shuru\\n'
          'Pickup: ${pickupController.text.trim()}\\n'
          'Drop: ${dropController.text.trim()}\\n\\n'
          'Yeh demo hai—abhi driver ko request nahi bheji gayi.';
    });
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('DNNSS Drive'),
        content: Text(bookingMessage!),
        actions: [
          FilledButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Theek hai'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Row(
          children: [
            Icon(Icons.local_taxi, color: brandYellow, size: 30),
            SizedBox(width: 10),
            Text('DNNSS Drive', style: TextStyle(fontWeight: FontWeight.w800)),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Help',
            onPressed: () => showAboutDialog(
              context: context,
              applicationName: 'DNNSS Drive',
              applicationVersion: '0.1.0 demo',
              children: const [
                Text('Local ride booking demo for Bike, Auto and Car.'),
              ],
            ),
            icon: const Icon(Icons.help_outline),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: brandBlack,
              borderRadius: BorderRadius.circular(22),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Aapki ride, aapke shehar mein',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 23,
                      fontWeight: FontWeight.bold,
                    )),
                SizedBox(height: 8),
                Text('Bijnor aur aas-paas ke liye ride booking',
                    style: TextStyle(color: Colors.white70, fontSize: 14)),
                SizedBox(height: 16),
                Row(
                  children: [
                    Icon(Icons.shield_outlined, color: brandYellow),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text('Simple • Local • Convenient',
                          style: TextStyle(color: brandYellow)),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 22),
          const Text('Ride choose karein',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          Row(
            children: [
              _vehicleCard('Bike', Icons.two_wheeler, '₹40 se'),
              const SizedBox(width: 8),
              _vehicleCard('Auto', Icons.electric_rickshaw, '₹80 se'),
              const SizedBox(width: 8),
              _vehicleCard('Car', Icons.directions_car, '₹150 se'),
            ],
          ),
          const SizedBox(height: 22),
          const Text('Kahan se kahan tak?',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          TextField(
            controller: pickupController,
            textInputAction: TextInputAction.next,
            decoration: InputDecoration(
              labelText: 'Pickup location',
              hintText: 'Jaise: Bus stand',
              prefixIcon: const Icon(Icons.my_location, color: Colors.green),
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: dropController,
            textInputAction: TextInputAction.done,
            decoration: InputDecoration(
              labelText: 'Drop location',
              hintText: 'Jaise: Railway station',
              prefixIcon: const Icon(Icons.location_on, color: Colors.red),
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 18),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: const Color(0xFFE6E6E6)),
            ),
            child: Row(
              children: [
                const Icon(Icons.payments_outlined, size: 30),
                const SizedBox(width: 12),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Shuruaati estimated fare',
                          style: TextStyle(color: Colors.black54)),
                      Text('Final fare backend se set hoga',
                          style: TextStyle(fontSize: 12, color: Colors.black54)),
                    ],
                  ),
                ),
                Text('₹$fare',
                    style: const TextStyle(
                        fontSize: 24, fontWeight: FontWeight.w800)),
              ],
            ),
          ),
          const SizedBox(height: 18),
          SizedBox(
            height: 54,
            child: FilledButton.icon(
              style: FilledButton.styleFrom(
                backgroundColor: brandYellow,
                foregroundColor: brandBlack,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15)),
              ),
              onPressed: bookRide,
              icon: const Icon(Icons.local_taxi),
              label: const Text('Ride book karein',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            ),
          ),
          const SizedBox(height: 18),
          const Text(
            'Demo version: abhi real driver matching, GPS tracking, login aur online payment connected nahi hain.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.black54, fontSize: 12),
          ),
        ],
      ),
    );
  }

  Widget _vehicleCard(String name, IconData icon, String price) {
    final selected = vehicle == name;
    return Expanded(
      child: InkWell(
        borderRadius: BorderRadius.circular(15),
        onTap: () => setState(() => vehicle = name),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 160),
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 4),
          decoration: BoxDecoration(
            color: selected ? brandYellow : Colors.white,
            borderRadius: BorderRadius.circular(15),
            border: Border.all(
              color: selected ? brandBlack : const Color(0xFFE2E2E2),
              width: selected ? 1.5 : 1,
            ),
          ),
          child: Column(
            children: [
              Icon(icon, size: 29),
              const SizedBox(height: 6),
              Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
              Text(price, style: const TextStyle(fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }
}
